import React, { useState } from "react";
import { NavLink, Outlet } from "react-router-dom";
import aboutBgImage from "../assets/img/about-bg.jpg";
import homeBgImage from "../assets/img/home-bg.jpg";
import postBgImage from "../assets/img/post-bg.jpg";
import contactBgImage from "../assets/img/contact-bg.jpg";

export default function RootLayout() {
  const [img, setImg] = useState(homeBgImage);

  const handleChangeImg = (newImg) => {
    setImg(newImg);
  };

  return (
    <div
      className="container"
      style={{
        backgroundImage: `url(${img})`,
        height: "50vh",
        width: "100vw",
        backgroundSize: "contain", 
        backgroundRepeat:"repeat", 
        backgroundPosition: "center", 
      }}
    >
      <nav className="navbar navbar-expand-lg navbar-light" id="mainNav">
        <div className="container px-4 px-lg-5">
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarResponsive"
            aria-controls="navbarResponsive"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            Menu <i className="fas fa-bars"></i>
          </button>
          <div className="collapse navbar-collapse" id="navbarResponsive">
            <ul className="navbar-nav ms-auto py-4 py-lg-0">
              <li className="nav-item">
                <NavLink
                  to="/"
                  className="nav-link px-lg-3 py-3 py-lg-4"
                  onClick={() => handleChangeImg(homeBgImage)}
                >
                  HOME
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  to="about"
                  className="nav-link px-lg-3 py-3 py-lg-4"
                  onClick={() => handleChangeImg(aboutBgImage)}
                >
                  ABOUT
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  to="posts"
                  className="nav-link px-lg-3 py-3 py-lg-4"
                  onClick={() => handleChangeImg(postBgImage)}
                >
                  POSTS
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  to="contact"
                  className="nav-link px-lg-3 py-3 py-lg-4"
                  onClick={() => handleChangeImg(contactBgImage)}
                >
                  CONTACT
                </NavLink>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <main>
        <div>
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quas eos
          quae ut maxime odio reprehenderit numquam, nihil qui sunt ad at, eius
          totam aliquid provident esse officia, non itaque eaque!
        </div>
        <Outlet />
      </main>
    </div>
  );
}
